<?php

usleep(rand(100, 999));

$root = '/var/www/html'; #$_SERVER["DOCUMENT_ROOT"];

include($root."/inc/vars.php");
require($root."/inc/classes/DB.php");
include($root."/inc/functions.php");

$_POST = json_decode(
	file_get_contents("php://input"),
	true
);

$type = exst($_POST["type"]);

$user_id = (int) exst($_POST["object"]["user_id"]);

if($db->num_rows($db->query("SELECT * FROM `$users_table` WHERE `user_id` = '".$user_id."'")) == 0) {
	$db->insert($users_table, array(
		"user_id"   => $user_id,
		"user_name" => get_user_name($user_id),
		"talking"   => -2
	));
}

$assoc = $db->assoc($db->query("SELECT * FROM `$users_table` WHERE `user_id` = '".$user_id."'"));

switch ($type) {
	case "confirmation":
		die("8c1293dc");
	case "message_new":
		$message = exst($_POST["object"]["body"]);
		$message_id = (int) $_POST["object"]["id"];

		if($db->num_rows($db->query("SELECT * FROM `$messages_table` WHERE `message_id` = '".$message_id."'")) == 0 || isset($_POST["skip_db_limit"])) {
			if(!isset($_POST["skip_db_limit"])) {
				$db->insert($messages_table, array(
					"message_id" => $message_id
				));
			}

			if(isset($_POST["object"]["fwd_messages"])) {
				/*
				$get_message = api("messages.getById", array(
					"message_ids"  => $message_id,
					"access_token" => $group_access_token
				));
				*/
			}

			$attachments_all = array();
			$sticker_id = 0;

			if($attachments = exst($_POST["object"]["attachments"])) {
				for($i = 0; $i < count($attachments); $i++) {
					$attachment = $attachments[$i];

					if($attachment["type"] == "sticker") {
						$sticker_id = $attachment[$attachment["type"]]["id"];

						break;
					}

					if($attachment["type"] == "photo") {
						$photo = $root."/photos/".md5(time()."_".$user_id."_".rand(999999, 999999999)).".jpg";

						file_put_contents($photo, file_get_contents(exst($attachment[$attachment["type"]]["photo_604"]))) or die(json_encode(error_get_last()));

						$get_server = api("photos.getMessagesUploadServer", array(
							"group_id"     => $group_id,
							"access_token" => $group_access_token
						));

						if($upload_url = exst($get_server["response"]["upload_url"])) {
							$upload = json_decode(
								curl($upload_url, array(
									"photo" => new CurlFile($photo)
								)),
								true
							);

							$server = exst($upload["server"]);
							$photo = exst($upload["photo"]);
							$hash = exst($upload["hash"]);

							if($server && $photo && $hash) {
								$save_photo = api("photos.saveMessagesPhoto", array(
									"group_id"     => $group_id,
									"server"       => $server,
									"photo"        => $photo,
									"hash"         => $hash,
									"access_token" => $group_access_token
								));

								if($response = exst($save_photo["response"][0])) {
									$attachments_all[] = "photo".$response["owner_id"]."_".$response["id"];
								}
							}
						}

						unlink($photo);
					} else {
						$attachments_all[] = $attachment["type"].$attachment[$attachment["type"]]["owner_id"]."_".$attachment[$attachment["type"]]["id"].((isset($attachment[$attachment["type"]]["access_key"])) ? "_".$attachment[$attachment["type"]]["access_key"]: "");
					}
				}
			}

			if($assoc["group_member"] == 0) {
				send_message($user_id, "Сначала подпишись на нашу группу и тогда начинай свое общение! Ты обязательно найдешь себе человека, с которым сможешь обсудить много хорошего аниме ☺\n\nДля подписки перейдите: vk.com/islachan");

				/*$db->update($users_table, array(
					"group_member" => 1
				), array(
					"user_id" => $user_id
				));*/
				
				die('ok');
			}

			if(preg_match("/stop/isu", $message) || preg_match("/стоп/isu", $message)) {
				if($assoc["talking"] == -2) die("ok");

				$talking = -2;
			} else if($assoc["talking"] >= 1) {
				send_message($assoc["talking"], $message, "Собеседник", implode(",", $attachments_all));

				$db->update($users_table, array(
					"sent_messages:+" => 1
				), array(
					"user_id"         => $assoc["user_id"]
				));
			} else if(preg_match("/start/isu", $message) || preg_match("/начать/isu", $message)) {
				if($assoc["talking"] >= 1) {
					die("ok");
				}

				if($assoc["user_sex"] == 0 || $assoc["user_sex_choose"] == 0) {
					if($assoc["user_sex"] == 0 && $assoc["user_sex_choose"] == 0) {
						$message = "&#128699; Выбери свой пол:\n\n1 -- мужской &#128113;".(($assoc["user_sex"] == 1) ? " (выбран)": "")."\n2 -- женский &#128105;".(($assoc["user_sex"] == 2) ? " (выбран)": "");
					} else if($assoc["user_sex"] == 0 && $assoc["user_sex_choose"] != 0) {
						$message = "&#128699; Выбери свой пол:\n\n1 -- мужской &#128113;".(($assoc["user_sex"] == 1) ? " (выбран)": "")."\n2 -- женский &#128105;".(($assoc["user_sex"] == 2) ? " (выбран)": "");
					} else {
						$message = "Выбери желаемый пол собеседника:\n\n3 -- мужской 	&#128102;".(($assoc["user_sex_choose"] == 1) ? " (выбран)": "")."\n4 -- женский &#128120;".(($assoc["user_sex_choose"] == 2) ? " (выбран)": "")."\n5 -- любой".(($assoc["user_sex_choose"] == 3) ? " (выбран)": "");
					}
					
					send_message($user_id, $message);

					die("ok");
				}

				$search_by_sex = $assoc["user_sex_choose"] != 3 ? " AND `user_sex` = ".$assoc["user_sex_choose"]."": "";
				$search_person = $db->query("SELECT * FROM `$users_table` WHERE `user_id` != '".$user_id."' AND `talking` = -1 AND (`user_sex_choose` = ".$assoc["user_sex"]." OR `user_sex_choose` = 3) AND `group_member` = 1".$search_by_sex." ORDER BY RAND()");
				

				if($db->num_rows($search_person) == 0) {
					$talking = -1;
				} else {
					$assoc_person = $db->assoc($search_person);

					$db->update($users_table, array(
						"talking" => $assoc_person["user_id"]
					), array(
						"user_id" => $assoc["user_id"]
					));
					$db->update($users_table, array(
						"talking" => $assoc["user_id"]
					), array(
						"user_id" => $assoc_person["user_id"]
					));

					$connection_good_message = "Соединение с собеседником успешно установлено. Для начала поздоровайся! \n\nЕсли собеседник долго не отвечает, тогда напиши".' "стоп" и после этого опять "начать". 🙏';

					send_message($assoc["user_id"], $connection_good_message);
					usleep(rand(100, 999));
					send_message($assoc_person["user_id"], $connection_good_message);
				}
			} else if(preg_match("/settings/isu", $message) || preg_match("/настройки/isu", $message)) {
				send_message($user_id, "&#128699; Выбери свой пол:\n\n1 -- мужской &#128113;".(($assoc["user_sex"] == 1) ? " (выбран)": "")."\n2 -- женский &#128105;".(($assoc["user_sex"] == 2) ? " (выбран)": "")."\n\nВыберите желаемый пол собеседника:\n\n3 -- мужской 	&#128102;".(($assoc["user_sex_choose"] == 1) ? " (выбран)": "")."\n4 -- женский &#128120;".(($assoc["user_sex_choose"] == 2) ? " (выбран)": "")."\n5 -- любой".(($assoc["user_sex_choose"] == 3) ? " (выбран)": ""));

				die("ok");
			} else if(preg_match("/online/isu", $message) || preg_match("/онлайн/isu", $message)) {
				$users = array();
				$users_online = 0;

				$query = $db->query("SELECT * FROM `$users_table` WHERE `group_member` = 1");

				while ($assoc = $db->assoc($query)) {
					$users[] = $assoc["user_id"];
				}

				$get_users = api("users.get", array(
					"user_ids" => implode(",", $users),
					"fields"   => "online"
				));
				$get_users_response = $get_users["response"];

				for ($i = 0; $i < count($get_users_response); $i++) {
					if(isset($get_users_response[$i]["online"]) && $get_users_response[$i]["online"] == 1) {
						$users_online++;
					}
				}

				$users_searching = $db->num_rows($db->query("SELECT * FROM `$users_table` WHERE `talking` = -1 AND `group_member` = 1"));

				send_message($user_id, "Сейчас в сети ".$users_online." ".endings($users_online, array("человек", "человек", "человека")).", ".$users_searching." из них ищет собеседника.");

				die("ok");
			} else if(preg_match("/статистика/isu", $message)) {
				send_message($user_id, "Всего ты отправил".(($assoc["user_sex"] == 2) ? "a": "")." ".$assoc["sent_messages"]." ".endings($assoc["sent_messages"], array("сообщений", "сообщение", "сообщения"))." &#128202;");

				die("ok");
			} else if(preg_match("/топ/isu", $message)) {
				$top_message = "ТОП 3 самых общительных участника:\n\n";

				$users = array();

				$query = $db->query("SELECT * FROM `$users_table` WHERE `user_id` ORDER BY `sent_messages` DESC LIMIT 3");

				for($i = 0; $i < $db->num_rows($query); $i++) {
					$assoc_user = $db->assoc($query);
					
					$top_message .= (($i == 0) ? "🥇": "") . (($i == 1) ? "🥈": "") .(($i == 2) ? "🥉": "");
					$top_message .= " [id".$assoc_user["user_id"]."|".$assoc_user["user_name"]."] -- отправил".(($assoc_user["user_sex"] == 2) ? "a": "")." ".$assoc_user["sent_messages"]." ".endings($assoc_user["sent_messages"], array("сообщений", "сообщение", "сообщения")).".\n";
				}
				
				send_message($user_id, $top_message);
			} else if(preg_match("/помощь/isu", $message) || preg_match("/help/isu", $message)) {
				send_message($user_id, "&#10068; Приветствую тебя в разделе <<помощь>>. Вот основные команды чата:\n\n1. Начать -- начинает поиск собеседника\n2. Стоп -- останавливает диалог или прекращает поиск собеседника \n3. Настройки -- предлагает изменить твой пол и пол желаемого собеседника \n4. Статистика -- показывает, сколько сообщений ты отправил".(($assoc["sex"] == 2) ? "a": "")."\n\n &#8252; Обрати внимание, что если ты с кем-то общаешься, то из списка команд работает только стоп, остальные можно вызвать только после выхода из диалога.");
			} else {
				if($message == 1 || $message == 2 || $message == 3 || $message == 4 || $message == 5) {
					if(strlen($message) > 1) {
						send_message($user_id, "Настройки не сохранены.\n\n &#8252; Обрати внимание, что за один запрос настроек можно сохранить только пол или только пол желаемого собеседника. Пример:\n\n-- Вводишь настройки \n -- Вводишь ответ (от 1 до 5) \n-- Если нужно, опять вводишь ответ (от 1 до 5)");

						die("ok");
					}

					$message = (int) $message;

					$user_sex = ($message == 1 || $message == 2) ? $message: $assoc["user_sex"];
					$user_sex_choose = ($message == 3 || $message == 4 || $message == 5) ? $message - 2: $assoc["user_sex_choose"];

					$db->query("UPDATE `$users_table` SET `settings_waiting` = 0, `user_sex` = $user_sex, `user_sex_choose` = $user_sex_choose WHERE `user_id` = '".$user_id."'");

					if($user_sex == 0 || $user_sex_choose == 0) {
						if($user_sex == 0 && $user_sex_choose == 0) {
							$message = "&#128699; Выбери свой пол:\n\n1 -- мужской &#128113;".(($user_sex == 1) ? " (выбран)": "")."\n2 -- женский &#128105;".(($user_sex== 2) ? " (выбран)": "");
						} else if($user_sex == 0 && $user_sex_choose != 0) {
							$message = "&#128699; Выбери свой пол:\n\n1 -- мужской &#128113;".(($user_sex == 1) ? " (выбран)": "")."\n2 -- женский &#128105;".(($user_sex == 2) ? " (выбран)": "");
						} else {
							$message = "Выбери желаемый пол собеседника:\n\n3 -- мужской 	&#128102;".(($user_sex_choose == 1) ? " (выбран)": "")."\n4 -- женский &#128120;".(($user_sex_choose == 2) ? " (выбран)": "")."\n5 -- любой".(($user_sex_choose == 3) ? " (выбран)": "");
						}

						send_message($user_id, $message);
					} else {
						send_message($user_id, "Настройки успешно сохранены. Чтобы найти собеседника, напиши начать.");
					}
				} else {
					send_message($user_id, "Команда не распознана. Напиши помощь, чтобы получить список команд.");
				}

				die("ok");
			}

			if($assoc["talking"] == -1 && $assoc["talking"] == exst($talking)) {
				send_message($assoc["user_id"], "Поиск собеседника уже запущен. Если нужно остановить поиск, воспользуйся командой стоп.");

				die("ok");
			}

			if($assoc["talking"] == exst($talking)) unset($talking);

			if(isset($talking)) {
				$db->query("UPDATE `$users_table` SET `talking` = $talking WHERE `user_id` = '".$user_id."'");

				if($talking == -1) {
					$message_result = "Ты добавлен".(($assoc["user_sex"] == 2) ? "a": "")." в очередь поиска, подожди немного, мы скоро найдём тебе собеседника.";
				} else if($talking == -2 && $assoc["talking"] >= 1) {
					$message_result = "Ты остановил".(($assoc["user_sex"] == 2) ? "a": "")." диалог и покинул".(($assoc["user_sex"] == 2) ? "a": "")." своего собеседника. \n\nДля того, чтобы начать общение, напиши начать, или напиши помощь, чтобы получить список команд.";

					$db->query("UPDATE `$users_table` SET `talking` = $talking WHERE `user_id` = '".$assoc["talking"]."'");

					send_message($assoc["talking"], "Собеседник покинул тебя.");
				} else if($talking == -2) {
					$message_result = "Поиск собеседника остановлен.";
				}

				send_message($user_id, $message_result);
			}
		}

		break;
	
	case "group_leave":
	
		$db->update($users_table, array(
			"group_member" => 0
		), array(
			"user_id" => $user_id
		));

		send_message($user_id, "Как жаль, что ты уходишь. Надеемся, что ты когда-то передумаешь и вернёшься обратно. 😒");

		break;

	case "group_join":
	
		$db->update($users_table, array(
			"group_member" => 1
		), array(
			"user_id" => $user_id
		));

		send_message($user_id, 'Привет! Огромное спасибо за подписку.'."\n\n".'Для 📢 начала общения напиши: "начать"'."\n".'Для 💡получения команд напиши: "помощь"'."\n\n".'Удачного общения! ');
		//send_message($admin_id, "[id$user_id|".$assoc["user_name"]."] вступил".(($assoc["user_sex"] == 2) ? "a": "")." в сообщество.");

		break;

	default:
		break;
}

echo "ok";
?>