<!DOCTYPE html>
<html>
	<head>
		<title>Not your business</title>
	</head>
	<body>
		<h1>Don't touch this</h1>
	</body>
</html>