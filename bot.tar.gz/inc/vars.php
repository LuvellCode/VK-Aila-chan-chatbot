<?php

$group_access_tokens = array(
	"",
	"",
	"",
);
$group_access_token = $group_access_tokens[rand(0, count($group_access_tokens) - 1)];
$access_token = "";

$group_id = 179445226;
$photos_album_id = 262964555;

$users_table = "AnonymBot.cf_users";
$messages_table = "AnonymBot.cf_messages";
$responses_table = "AnonymBot.cf_responses";
$posts_table = "AnonymBot.cf_posts";

$page = "/index.php";

?>