<?php
function exst(&$var = null) {
    return isset($var) ? $var: "";
}

function post($url = null, $data = array(), $cookie = null) {
    $ch = curl_init();

    $headers = array(
        "accept:text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
        "accept-language:ru-RU,ru;q=0.8,en-US;q=0.6,en;q=0.4",
        "user-agent:Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.3.2924.87 Safari/537.36"
    );

    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HEADER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

    if(isset($data)) {
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    }

    if(isset($cookie)) {
        curl_setopt($ch, CURLOPT_COOKIE, $cookie);
    }

    $response = curl_exec($ch);

    preg_match_all("/Set-Cookie: (.*?);/", $response, $cookie);

    $content = substr($response, curl_getinfo($ch, CURLINFO_HEADER_SIZE));
    $header = substr($response, 0, curl_getinfo($ch, CURLINFO_HEADER_SIZE));

    return array(
        "content" => $content, 
        "header"  => $header, 
        "cookie"  => implode(";", $cookie[1])
    );
}

function curl($url = null, $data = null) {
    $ch = curl_init();

    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);    

    if(isset($data)) {
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    }

    return curl_exec($ch);
}

function api($method = null, $data = null) {
    global $db, $responses_table;

    $captcha_sid = exst($GLOBALS["_POST"]["csid"]);
    $captcha_key = exst($GLOBALS["_POST"]["ckey"]);

    if($captcha_sid && $captcha_key) {
        $data["captcha_sid"] = $captcha_sid;
        $data["captcha_key"] = $captcha_key;
    }

    $data["v"] = 5.68;

    $response = curl("https://api.vk.com/method/$method", $data);

    if(strlen($response) == 0) {
        return api($method, $data);
    }

    $decode = json_decode(
        $response, 
        true
    );

    if(!isset($decode["response"])) {
        $db->insert($responses_table, array(
            "response" => $response,
            "date"     => date("d.m.Y H:i:s")
        ));

        if(exst($decode["error"]["error_code"]) == 14) {
            $postfields = array();

            foreach ($data as $key => $value) {
                $postfields[] = "$key=$value";
            }

            $GLOBALS["captcha"]->insert($decode["error"]["captcha_sid"], $decode["error"]["captcha_img"], implode("&", $postfields));
        }
    }

    if(exst($decode["error"]["error_code"]) == 6) {
        usleep(rand(100, 999));

        return api($method, $data);
    }

    return $decode;
}

function get_user_name($user_id = null) {
    $get_user = api("users.get", array(
        "user_id" => $user_id,
        "lang"    => "ru"
    ));
    $get_user_response = exst($get_user["response"][0]);

    return $get_user_response["first_name"]." ".$get_user_response["last_name"];
}

function endings($number = null, $endings = array()) {
    $num100 = $number % 100;
    $num10 = $number % 10;
    if ($num100 >= 5 && $num100 <= 20) {
        return $endings[0];
    } else if ($num10 == 0) {
        return $endings[0];
    } else if ($num10 == 1) {
        return $endings[1];
    } else if ($num10 >= 2 && $num10 <= 4) {
        return $endings[2];
    } else if ($num10 >= 5 && $num10 <= 9) {
        return $endings[0];
    } else {
        return $endings[2];
    }
}

function send_message($user_id = null, $message = null, $title = null, $attachment = null) {
    global $group_access_token;

    return api("messages.send", array(
        "user_id"      => $user_id,
        "message"      => $message,
        "title"        => $title,
        "attachment"   => $attachment,
        "access_token" => $group_access_token
    ));
}
?>