<?php
class users {
	protected $db = null;

	public $user_id = null;

	public $assoc = array();

	public function __construct() {
		$this->db = $GLOBALS["db"];
	}

	public function init($user_id = null) {
		$this->user_id = (int) $user_id;

		if($user_id < 1) die("ok");

		if(!$this->is_user()) {
			$this->insert();
		}
	}

	public function is_user() {
		return $this->db->num_rows($this->db->query("SELECT * FROM `".$GLOBALS["users_table"]."` WHERE `user_id` = '".$this->user_id."'")) == 0 ? false: true;
	}

	public function insert($user_id = null) {
		$this->db->insert($GLOBALS["users_table"], array(
			"user_id" => $this->user_id,
			"talking" => -2
		));
	}
}

$users = new users;
?>