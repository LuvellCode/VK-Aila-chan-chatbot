<?php
class bot {
	protected $db = null;

	public function __construct() {
		global $db;

		$this->db = $db;
	}

	public function send($user_id = null, $message = null, $attachments = null) {
		api("messages.send", array(
			"user_id"      => $user_id,
			"message"      => $message,
			"attachment"   => $attachments,
			"access_token" => $GLOBALS["group_access_token"]
		));
	}
}

$bot = new bot;
?>